# FF MAX Fire Button Assistant (HTML/CSS/JS in Android WebView + native overlay)

STATUS: not compiled or tested on a device by the author. Expect to fix small build errors.

Build: open in Android Studio (JDK 17), sync (creates the Gradle wrapper), Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk. Install with `adb install` or copy to the phone (allow unknown sources).
minSdk 26 (Android 8+, so Android 9+ is covered).

UI: app/src/main/assets/index.html (Home, Fire Button, Sensitivity, Display, Practice, About).
Native: MainActivity (WebView + JS bridge), OverlayService (floating button), FireAccessibilityService (relays your held touch), Prefs.

Not included: aim assist, auto-targeting, screen reading, any headshot guarantee.
