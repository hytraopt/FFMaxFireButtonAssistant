package com.ffmax.firebutton

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Holds a touch at (x,y) on the screen while the overlay button is held, optionally sliding it. */
class FireAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: FireAccessibilityService? = null }

    private var last: GestureDescription.StrokeDescription? = null
    private var held = false
    private var inFlight = false
    private var curX = 0f; private var curY = 0f
    private var wantX = 0f; private var wantY = 0f
    private val seg = 40L

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { held = false; last = null; inFlight = false }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun press(x: Float, y: Float) {
        if (held) return
        held = true; curX = x; curY = y; wantX = x; wantY = y
        send(GestureDescription.StrokeDescription(path(x, y, x, y), 0, seg, true))
    }

    fun moveTo(x: Float, y: Float) { if (held) { wantX = x; wantY = y } }

    fun release() { held = false; if (!inFlight) finish() }

    private fun path(ax: Float, ay: Float, bx: Float, by: Float) =
        Path().apply { moveTo(ax, ay); if (ax != bx || ay != by) lineTo(bx, by) }

    private fun send(s: GestureDescription.StrokeDescription) {
        inFlight = true; last = s
        val g = GestureDescription.Builder().addStroke(s).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                inFlight = false
                if (held) {
                    val p = path(curX, curY, wantX, wantY); curX = wantX; curY = wantY
                    send(s.continueStroke(p, 0, seg, true))
                } else finish()
            }
            override fun onCancelled(d: GestureDescription?) { inFlight = false; last = null; held = false }
        }, null)
        if (!ok) { inFlight = false; held = false; last = null }
    }

    private fun finish() {
        val s = last ?: return
        last = null
        val p = path(curX, curY, wantX, wantY)
        dispatchGesture(GestureDescription.Builder().addStroke(s.continueStroke(p, 0, 10, false)).build(), null, null)
    }
}
