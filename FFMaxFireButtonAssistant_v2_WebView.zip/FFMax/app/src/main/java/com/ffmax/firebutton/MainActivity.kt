package com.ffmax.firebutton

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView

/** Hosts the HTML/CSS/JS UI (assets/index.html) and exposes native functions through the "Android" bridge. */
class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        window.statusBarColor = 0xFF0B0F14.toInt()
        window.navigationBarColor = 0xFF0B0F14.toInt()
        web = WebView(this)
        web.setBackgroundColor(0xFF0B0F14.toInt())
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; allowContentAccess = false   // bundled assets still load
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun refresh() {
        if (OverlayService.running)
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_REFRESH))
    }

    inner class Bridge {
        @JavascriptInterface fun getSettings(): String =
            """{"size":${Prefs.sizeDp(this@MainActivity)},"alpha":${Prefs.alphaPct(this@MainActivity)},""" +
                """"sens":${Prefs.sens(this@MainActivity)},"edit":${Prefs.edit(this@MainActivity)}}"""

        @JavascriptInterface fun setInt(key: String, v: Int) {
            val ok = when (key) { "size" -> v in 40..160; "alpha" -> v in 20..100; "sens" -> v in 1..100; else -> false }
            if (!ok) return
            Prefs.putInt(this@MainActivity, key, v)
            runOnUiThread { refresh() }
        }

        @JavascriptInterface fun setEdit(v: Boolean) {
            Prefs.setEdit(this@MainActivity, v); runOnUiThread { refresh() }
        }

        @JavascriptInterface fun status(): String =
            """{"overlayPerm":${Settings.canDrawOverlays(this@MainActivity)},""" +
                """"a11y":${FireAccessibilityService.instance != null},"running":${OverlayService.running}}"""

        @JavascriptInterface fun toggleOverlay(): String {
            if (OverlayService.running) {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                return "stopped"
            }
            if (!Settings.canDrawOverlays(this@MainActivity)) return "need_overlay_permission"
            return try {
                startForegroundService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_START))
                "started"
            } catch (e: Exception) { "error: ${e.message}" }
        }

        @JavascriptInterface fun openOverlayPermission() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun openAccessibility() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        @JavascriptInterface fun resetPositions() { Prefs.clearPos(this@MainActivity); runOnUiThread { refresh() } }
    }
}
