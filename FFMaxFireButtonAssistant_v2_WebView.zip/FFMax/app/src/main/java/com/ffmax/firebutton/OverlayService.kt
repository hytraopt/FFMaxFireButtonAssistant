package com.ffmax.firebutton

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "start"; const val ACTION_STOP = "stop"
        const val ACTION_REFRESH = "refresh"; const val ACTION_EDIT_OFF = "edit_off"
        @Volatile var running = false
        private const val CH = "overlay"
    }

    private lateinit var wm: WindowManager
    private var button: FireButtonView? = null
    private var marker: MarkerView? = null
    private var btnLp: WindowManager.LayoutParams? = null
    private var mkLp: WindowManager.LayoutParams? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_EDIT_OFF -> Prefs.setEdit(this, false)
        }
        startFg()
        running = true
        rebuild()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (running) rebuild()
    }

    override fun onDestroy() {
        removeViews(); running = false; super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Fire button overlay", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String, code: Int) = PendingIntent.getService(this, code,
            Intent(this, OverlayService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Fire button active")
            .setContentText(if (Prefs.edit(this)) "Edit mode: drag the button and the green marker" else "Overlay running")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_save, "Lock position", pi(ACTION_EDIT_OFF, 1))
            .addAction(android.R.drawable.ic_delete, "Stop", pi(ACTION_STOP, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun removeViews() {
        button?.let { runCatching { wm.removeView(it) } }; button = null
        marker?.let { runCatching { wm.removeView(it) } }; marker = null
    }

    private fun lp(size: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun rebuild() {
        removeViews()
        val dm = resources.displayMetrics
        val sw = dm.widthPixels; val sh = dm.heightPixels
        val size = (Prefs.sizeDp(this) * dm.density).toInt()
        val edit = Prefs.edit(this)

        val bp = Prefs.pos(this, "btn") ?: Pair(sw - size * 2, sh - size * 2)
        val b = FireButtonView(this).apply { alpha = Prefs.alphaPct(this@OverlayService) / 100f }
        val bl = lp(size, bp.first.coerceIn(0, maxOf(0, sw - size)), bp.second.coerceIn(0, maxOf(0, sh - size)))
        btnLp = bl; button = b
        wm.addView(b, bl)
        attachButton(b, bl)

        if (edit) {
            val ms = (48 * dm.density).toInt()
            val tp = Prefs.pos(this, "tgt") ?: Pair((sw * 0.85f).toInt(), (sh * 0.7f).toInt())
            val m = MarkerView(this)
            val ml = lp(ms, (tp.first - ms / 2).coerceIn(0, sw - ms), (tp.second - ms / 2).coerceIn(0, sh - ms))
            mkLp = ml; marker = m
            wm.addView(m, ml)
            Prefs.setPos(this, "tgt", ml.x + ms / 2, ml.y + ms / 2)
            attachDrag(m, ml) { Prefs.setPos(this, "tgt", ml.x + ms / 2, ml.y + ms / 2) }
        }
    }

    private fun attachDrag(v: android.view.View, l: WindowManager.LayoutParams, onSave: () -> Unit) {
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = l.x; sy = l.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val dm = resources.displayMetrics
                    l.x = (sx + (e.rawX - dx)).toInt().coerceIn(0, maxOf(0, dm.widthPixels - l.width))
                    l.y = (sy + (e.rawY - dy)).toInt().coerceIn(0, maxOf(0, dm.heightPixels - l.height))
                    runCatching { wm.updateViewLayout(view, l) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onSave()
            }
            true
        }
    }

    private fun attachButton(b: FireButtonView, l: WindowManager.LayoutParams) {
        if (Prefs.edit(this)) {
            attachDrag(b, l) { Prefs.setPos(this, "btn", l.x, l.y) }
            return
        }
        var baseX = 0f; var baseY = 0f; var rx = 0f; var ry = 0f
        b.setOnTouchListener { _, e ->
            val svc = FireAccessibilityService.instance
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    b.down = true
                    if (svc == null) {
                        Toast.makeText(this, "Enable the FF MAX accessibility service first", Toast.LENGTH_SHORT).show()
                    } else {
                        val dm = resources.displayMetrics
                        val t = Prefs.pos(this, "tgt") ?: Pair((dm.widthPixels * 0.85f).toInt(), (dm.heightPixels * 0.7f).toInt())
                        baseX = t.first.toFloat(); baseY = t.second.toFloat(); rx = e.rawX; ry = e.rawY
                        svc.press(baseX, baseY)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val dm = resources.displayMetrics
                    val m = Prefs.sensMul(Prefs.sens(this))
                    svc?.moveTo((baseX + (e.rawX - rx) * m).coerceIn(1f, dm.widthPixels - 1f),
                        (baseY + (e.rawY - ry) * m).coerceIn(1f, dm.heightPixels - 1f))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { b.down = false; svc?.release() }
            }
            true
        }
    }
}
