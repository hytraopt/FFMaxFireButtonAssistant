package com.ffmax.firebutton

import android.content.Context
import android.content.res.Configuration

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("ffmax", Context.MODE_PRIVATE)
    private fun o(c: Context) =
        if (c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "L" else "P"

    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()

    fun sizeDp(c: Context) = getInt(c, "size", 72)
    fun alphaPct(c: Context) = getInt(c, "alpha", 85)
    fun sens(c: Context) = getInt(c, "sens", 50)
    fun edit(c: Context) = sp(c).getBoolean("edit", false)
    fun setEdit(c: Context, v: Boolean) = sp(c).edit().putBoolean("edit", v).apply()

    /** Positions are stored per orientation. name: "btn" (top-left) or "tgt" (center of real fire button). */
    fun pos(c: Context, name: String): Pair<Int, Int>? {
        val s = sp(c); val kx = "${name}X${o(c)}"
        return if (s.contains(kx)) Pair(s.getInt(kx, 0), s.getInt("${name}Y${o(c)}", 0)) else null
    }
    fun setPos(c: Context, name: String, x: Int, y: Int) =
        sp(c).edit().putInt("${name}X${o(c)}", x).putInt("${name}Y${o(c)}", y).apply()
    fun clearPos(c: Context) {
        val e = sp(c).edit()
        for (n in listOf("btn", "tgt")) for (s in listOf("L", "P")) { e.remove("${n}X$s"); e.remove("${n}Y$s") }
        e.apply()
    }

    /** Sensitivity 1..100 -> multiplier 0.3x .. 3.0x (logarithmic). */
    fun sensMul(s: Int): Float = (0.3 * Math.pow(10.0, (s - 1) / 99.0)).toFloat()
}
