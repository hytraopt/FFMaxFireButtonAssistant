package com.ffmax.firebutton

import android.content.Context
import android.graphics.*
import android.view.View

class FireButtonView(ctx: Context) : View(ctx) {
    var down = false
        set(v) { field = v; invalidate() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xCCFFFFFF.toInt() }
    private val flameP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val flame = Path().apply {
        moveTo(.5f, 0f)
        cubicTo(.55f, .25f, .92f, .40f, .85f, .68f)
        cubicTo(.82f, .90f, .65f, 1f, .5f, 1f)
        cubicTo(.35f, 1f, .18f, .90f, .15f, .68f)
        cubicTo(.12f, .50f, .30f, .40f, .36f, .22f)
        cubicTo(.42f, .34f, .46f, .30f, .5f, 0f)
        close()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = w / 2f
        fill.shader = RadialGradient(r, r, r, intArrayOf(0xFFFFB300.toInt(), 0xFFFF5100.toInt(), 0xFFB71C1C.toInt()),
            floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        ring.strokeWidth = w * 0.045f
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val r = w / 2f
        val s = if (down) 0.9f else 1f
        c.save(); c.scale(s, s, r, r)
        c.drawCircle(r, r, r - ring.strokeWidth, fill)
        c.drawCircle(r, r, r - ring.strokeWidth, ring)
        c.translate(w * .27f, w * .22f); c.scale(w * .46f, w * .56f)
        c.drawPath(flame, flameP)
        c.restore()
    }
}

class MarkerView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF00E676.toInt() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val r = w / 2f
        p.strokeWidth = w * 0.06f
        c.drawCircle(r, r, r - p.strokeWidth, p)
        c.drawLine(r, w * .2f, r, w * .8f, p); c.drawLine(w * .2f, r, w * .8f, r, p)
    }
}
